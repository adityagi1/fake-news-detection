I have attached the Rscript files for each of the steps I have mentioned in my report.
1) dataset_formation.R
2)nlp.R
3)socialmedia.R
4)webstats.R
5)tidying_basedata.r

I have also attached the final dataset I had used for my modelling. It is titled "reduced_data.csv".
It was generated using the R commands in the "dataset_formation.R file".